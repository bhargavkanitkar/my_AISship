import 'dotenv/config'
import fs from 'node:fs'
import path from 'node:path'
import { WebSocketServer, WebSocket } from 'ws'

const port = 8787
const wss = new WebSocketServer({ port })
const historyFile = path.join(process.cwd(), 'ais-history.json')
const eventsFile = path.join(process.cwd(), 'ais-silence-events.json')
const historyWindow = 4 * 60 * 60 * 1000
const silenceThreshold = 10 * 60 * 1000
const history = new Map()
const vessels = new Map()
const silenceEvents = []
let upstreamStatus = 'connecting'
const broadcast = (payload) => wss.clients.forEach((client) => { if (client.readyState === WebSocket.OPEN) client.send(JSON.stringify(payload)) })

try {
  const saved = JSON.parse(fs.readFileSync(historyFile, 'utf8'))
  Object.entries(saved).forEach(([mmsi, points]) => history.set(mmsi, points.filter((point) => point.lat >= -60 && point.lat <= 30 && point.lon >= 20 && point.lon <= 120)))
} catch { /* No history exists on the first run. */ }
try { silenceEvents.push(...JSON.parse(fs.readFileSync(eventsFile, 'utf8'))) } catch { /* No silence events exist on the first run. */ }

function pruneHistory() {
  const cutoff = Date.now() - historyWindow
  history.forEach((points, mmsi) => {
    const recent = points.filter((point) => point.timestamp >= cutoff)
    if (recent.length) history.set(mmsi, recent)
    else history.delete(mmsi)
  })
}

function saveHistory() {
  pruneHistory()
  fs.writeFileSync(historyFile, JSON.stringify(Object.fromEntries(history)))
}

function saveEvents() { fs.writeFileSync(eventsFile, JSON.stringify(silenceEvents.slice(0, 500))) }
function isPortLike(data) {
  return (data.speed ?? 0) <= 1 && [1, 5, 6].includes(data.navigationStatus)
}

wss.on('connection', (client) => {
  client.send(JSON.stringify({ type: 'status', status: upstreamStatus }))
  client.send(JSON.stringify({ type: 'history', points: [...history.entries()].flatMap(([mmsi, points]) => points.map((point) => ({ mmsi, ...point }))) }))
  client.send(JSON.stringify({ type: 'silence-history', events: silenceEvents.slice(0, 100) }))
})

function connectUpstream() {
  const upstream = new WebSocket('wss://stream.aisstream.io/v0/stream', { perMessageDeflate: true })
  upstream.on('open', () => {
    upstreamStatus = 'connected'
    console.log('AIS upstream connected; subscribing to vessel positions')
    upstream.send(JSON.stringify({ APIKey: process.env.AISSTREAM_API_KEY, BoundingBoxes: [[[-60, 20], [30, 120]]], FilterMessageTypes: ['PositionReport'] }))
    broadcast({ type: 'status', status: 'connected' })
  })
  upstream.on('message', (raw) => {
    const message = JSON.parse(raw.toString())
    if (message.Error) { upstreamStatus = 'error'; console.error('AIS upstream rejected subscription:', message.Error); broadcast({ type: 'status', status: 'error', message: message.Error }); return }
    const report = message.Message?.PositionReport
    if (!report || report.Latitude == null || report.Longitude == null) return
    const data = { mmsi: String(message.MetaData?.MMSI ?? report.UserID ?? ''), name: message.MetaData?.ShipName?.trim() || 'UNKNOWN VESSEL', lat: report.Latitude, lon: report.Longitude, speed: report.Sog, course: report.Cog, heading: report.TrueHeading, navigationStatus: report.NavigationalStatus, timestamp: Date.now() }
    const previous = vessels.get(data.mmsi)
    const maxSpeed = Math.max(previous?.maxSpeed ?? 0, Number.isFinite(data.speed) ? data.speed : 0)
    if (previous?.silentSince && !isPortLike(data) && !isPortLike(previous.last)) {
      const durationMs = data.timestamp - previous.silentSince
      const event = { id: `${data.mmsi}-${previous.last.timestamp}`, phase: 'resumed', mmsi: data.mmsi, name: data.name, off: previous.last, on: data, durationMs, maxSpeed, maxDistanceNm: maxSpeed * durationMs / 3600000, radiusMeters: maxSpeed * durationMs / 3600000 * 1852 }
      silenceEvents.unshift(event)
      saveEvents()
      broadcast({ type: 'silence-event', event })
    }
    vessels.set(data.mmsi, { last: data, maxSpeed, silentSince: isPortLike(data) ? null : previous?.silentSince ?? null })
    const points = history.get(data.mmsi) || []
    points.push({ lat: data.lat, lon: data.lon, timestamp: data.timestamp })
    history.set(data.mmsi, points)
    broadcast(data)
  })
  upstream.on('error', (error) => { upstreamStatus = 'error'; console.error('AIS upstream error:', error.message); broadcast({ type: 'status', status: 'error', message: error.message }) })
  upstream.on('close', (code, reason) => { upstreamStatus = 'closed'; console.log(`AIS upstream closed (${code}): ${reason.toString() || 'no reason'}; retrying in 5 seconds`); broadcast({ type: 'status', status: 'closed' }); setTimeout(connectUpstream, 5000) })
}

connectUpstream()
setInterval(saveHistory, 10000)
setInterval(() => {
  const now = Date.now()
  vessels.forEach((state, mmsi) => {
    if (!state.silentSince && !isPortLike(state.last) && now - state.last.timestamp >= silenceThreshold) {
      state.silentSince = state.last.timestamp
      const event = { id: `${mmsi}-${state.last.timestamp}`, phase: 'off', mmsi, name: state.last.name, off: state.last, maxSpeed: state.maxSpeed, durationMs: now - state.last.timestamp, maxDistanceNm: state.maxSpeed * (now - state.last.timestamp) / 3600000, radiusMeters: state.maxSpeed * (now - state.last.timestamp) / 3600000 * 1852 }
      broadcast({ type: 'silence-event', event })
    }
  })
}, 30000)
setInterval(() => { vessels.forEach((state) => { if (state.silentSince) { state.silentSince = state.silentSince } }); saveEvents() }, 60000)
console.log(`AIS proxy listening on ws://localhost:${port}`)
