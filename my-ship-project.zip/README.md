# SeaLane - Real-Time AIS Maritime Intelligence

Real-time vessel tracking and AIS silence detection over NASA GIBS Earth imagery.

## 🚀 Getting Started

### 1. Prerequisites
- [Node.js](https://nodejs.org/) (version 18 or newer recommended)
- A free API key from [aisstream.io](https://aisstream.io)

### 2. Setup
1. Clone the repository or extract the ZIP file.
2. Create a `.env` file in the project root:
   ```env
   AISSTREAM_API_KEY=your_api_key_here
   ```
3. Install dependencies:
   ```bash
   npm install
   ```

### 3. Running Locally
Start the backend WebSocket proxy and the Vite development server:

- **Terminal 1 (Backend WebSocket Server):**
  ```bash
  node server.mjs
  ```
- **Terminal 2 (Frontend UI):**
  ```bash
  npm run dev
  ```

Open [http://localhost:5180/](http://localhost:5180/) in your browser.
