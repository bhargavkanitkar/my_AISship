import 'leaflet/dist/leaflet.css'
import './style.css'
import L from 'leaflet'

type Vessel = { mmsi: string; name: string; lat: number; lon: number; speed?: number; course?: number; heading?: number; navigationStatus?: number; timestamp: number }
type SilenceEvent = { id: string; phase: 'off' | 'resumed'; mmsi: string; name: string; off: Vessel; on?: Vessel; durationMs: number; maxSpeed: number; maxDistanceNm: number; radiusMeters: number }
type DisplayVessel = Vessel & { estimated?: boolean }
const vessels = new Map<string, { marker: any; data: Vessel }>()
const crowdMarkers = new Map<string, any>()
const silenceEvents = new Map<string, SilenceEvent>()
const silenceLayers = new Map<string, { off: any; on?: any; radius: any }>()
const tracks = new Map<string, any>()
const trackPoints = new Map<string, Array<{ lat: number; lon: number; timestamp: number }>>()
const pendingVessels = new Map<string, Vessel>()
let selectedMmsi: string | null = null
let updateFrame = 0
const historyWindow = 4 * 60 * 60 * 1000

document.querySelector<HTMLDivElement>('#app')!.innerHTML = `<header class="topbar"><div class="brand"><span class="brand-mark">◒</span><span>SEALANE</span></div><div class="eyebrow">LIVE AIS / NASA GIBS</div><div class="top-actions"><label class="search"><span>⌕</span><input id="ship-search" type="search" placeholder="Search name or MMSI" autocomplete="off"><div id="search-results" class="search-results"></div></label><div id="connection" class="connection"><span class="pulse"></span>CONNECTING</div></div></header><main><section class="intro"><div><p class="kicker">MARITIME INTELLIGENCE</p><h1>Track the moving ocean.</h1><p class="lede">Real-time vessel positions over NASA Earth imagery.</p></div><div class="readout"><span class="readout-label">VESSELS IN VIEW</span><strong id="count">0</strong></div></section><section class="workspace"><div id="map"><div id="map-status" class="map-status">Loading NASA GIBS map...</div><div id="map-resolution" class="map-resolution"></div></div><aside class="sidebar"><div class="side-head"><span>RECENT SIGNALS</span><span class="live-dot"></span></div><div id="vessel-list" class="vessel-list"><div class="empty">Waiting for AIS positions<span>Ships will appear as the live stream connects.</span></div></div><section id="details" class="details"><div class="details-empty">Select a ship on the map</div></section><section id="silence-window" class="silence-window"><div class="silence-title"><span>AIS SILENCE EVENTS</span><span class="silence-count">0</span></div><p class="silence-note">Ships absent for 10+ minutes</p><div id="silence-list"><div class="details-empty">No silence events yet</div></div></section><div class="legend"><div><span class="legend-dot"></span> Active vessel</div><div><span class="legend-line"></span> 4-hour ship history</div><div><span class="event-off-key"></span> AIS off / on</div></div></aside></section></main><footer><span>NASA GIBS / AISSTREAM.IO</span><span id="updated">NO SIGNAL YET</span><span>IST</span></footer>`

const count = document.querySelector('#count')!
const list = document.querySelector('#vessel-list')!
const connection = document.querySelector('#connection')!
const updated = document.querySelector('#updated')!
const details = document.querySelector('#details')!
const silenceList = document.querySelector('#silence-list')!
const silenceCount = document.querySelector('.silence-count')!
const searchInput = document.querySelector<HTMLInputElement>('#ship-search')!
const searchResults = document.querySelector('#search-results')!
const resolution = document.querySelector('#map-resolution')!

function formatDegrees(value: number | undefined) { return value == null || value >= 511 ? '--' : `${Math.round(value)}°` }
function formatIstTime(timestamp: number) { return new Intl.DateTimeFormat('en-IN', { timeZone: 'Asia/Kolkata', hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' }).format(new Date(timestamp)) }
function reportAge(timestamp: number) { return `${Math.max(0, Math.floor((Date.now() - timestamp) / 1000))}s ago` }
function renderSearch(query: string) {
  const term = query.trim().toLowerCase()
  if (!term) { searchResults.innerHTML = ''; searchResults.classList.remove('visible'); return }
  const matches = [...vessels.values()].filter(({ data }) => data.name.toLowerCase().includes(term) || data.mmsi.includes(term)).sort((a, b) => b.data.timestamp - a.data.timestamp).slice(0, 12)
  searchResults.innerHTML = matches.length ? matches.map(({ data }) => `<button class="search-result" data-mmsi="${data.mmsi}"><span><strong>${data.name || 'UNKNOWN VESSEL'}</strong><small>MMSI ${data.mmsi} · updated ${reportAge(data.timestamp)}</small></span><em>${data.speed?.toFixed(1) ?? '--'} kn</em></button>`).join('') : '<div class="search-empty">No matching vessel in the live index</div>'
  searchResults.classList.add('visible')
  searchResults.querySelectorAll<HTMLButtonElement>('.search-result').forEach((result) => result.onclick = () => { selectVessel(result.dataset.mmsi!); searchInput.value = vessels.get(result.dataset.mmsi!)?.data.name || result.dataset.mmsi!; searchResults.classList.remove('visible') })
}
function formatDuration(ms: number) { const minutes = Math.floor(ms / 60000); return minutes < 60 ? `${minutes}m` : `${Math.floor(minutes / 60)}h ${minutes % 60}m` }
function silenceInfo(event: SilenceEvent) { return `<div class="ship-popup"><strong>${event.name || 'UNKNOWN VESSEL'}</strong><span>MMSI ${event.mmsi}</span><span>AIS off: ${formatIstTime(event.off.timestamp)} IST</span><span>${event.on ? `AIS on: ${formatIstTime(event.on.timestamp)} IST` : 'AIS still silent'}</span><span>Silent for ${formatDuration(event.durationMs)}</span><span>Peak speed ${event.maxSpeed.toFixed(1)} knots</span><span>Max range ${event.maxDistanceNm.toFixed(1)} nautical miles</span></div>` }
function renderSilenceEvents() {
  const events = [...silenceEvents.values()].sort((a, b) => (b.on?.timestamp ?? b.off.timestamp) - (a.on?.timestamp ?? a.off.timestamp)).slice(0, 12)
  silenceCount.textContent = String(silenceEvents.size)
  silenceList.innerHTML = events.length ? events.map((event) => `<button class="silence-row" data-event="${event.id}"><span class="event-off-key"></span><span><strong>${event.name || event.mmsi}</strong><small>${event.mmsi} · ${event.on ? 'RESUMED' : 'SILENT'}</small></span><em>${event.maxDistanceNm.toFixed(0)} nm</em></button>`).join('') : '<div class="details-empty">No silence events yet</div>'
  silenceList.querySelectorAll<HTMLButtonElement>('.silence-row').forEach((row) => row.onclick = () => { const layer = silenceLayers.get(row.dataset.event!); if (layer) map.flyTo(layer.off.getLatLng(), Math.max(map.getZoom(), 7)) })
}
function showSilenceEvent(event: SilenceEvent) {
  const previous = silenceLayers.get(event.id)
  if (previous) { previous.off.setPopupContent(silenceInfo(event)); previous.radius.setRadius(event.radiusMeters); if (event.on && !previous.on) previous.on = L.marker([event.on.lat, event.on.lon], { icon: L.divIcon({ className: 'ais-on-marker', html: '<span>ON</span>', iconSize: [24, 16], iconAnchor: [12, 8] }) }).addTo(map).bindPopup(silenceInfo(event)) }
  else {
    const off = L.marker([event.off.lat, event.off.lon], { icon: L.divIcon({ className: 'ais-off-marker', html: '<span>OFF</span>', iconSize: [28, 16], iconAnchor: [14, 8] }) }).addTo(map).bindPopup(silenceInfo(event))
    const radius = L.circle([event.off.lat, event.off.lon], { radius: event.radiusMeters, color: '#ff7979', weight: 1, opacity: 0.8, fillColor: '#ff7979', fillOpacity: 0.06, dashArray: '4 4' }).addTo(map)
    const on = event.on ? L.marker([event.on.lat, event.on.lon], { icon: L.divIcon({ className: 'ais-on-marker', html: '<span>ON</span>', iconSize: [24, 16], iconAnchor: [12, 8] }) }).addTo(map).bindPopup(silenceInfo(event)) : undefined
    silenceLayers.set(event.id, { off, on, radius })
  }
  silenceEvents.set(event.id, event)
  renderSilenceEvents()
}
function vesselInfo(data: DisplayVessel) { const age = Math.max(0, Math.floor((Date.now() - data.timestamp) / 1000)); return `<div class="ship-popup"><strong>${data.name || 'UNKNOWN VESSEL'}</strong><span>MMSI ${data.mmsi}</span><span>Speed ${data.speed?.toFixed(1) ?? '--'} knots</span><span>Course ${formatDegrees(data.course)}</span><span>Heading ${formatDegrees(data.heading)}</span><span>${data.estimated ? 'Estimated position' : 'Position'} ${data.lat.toFixed(5)}, ${data.lon.toFixed(5)}</span><span>Nav status ${data.navigationStatus ?? '--'}</span><span>Report age ${age}s</span><span>Last AIS ${formatIstTime(data.timestamp)} IST</span></div>` }
function positionAt(data: Vessel, now = Date.now()): DisplayVessel {
  if (data.speed == null || data.course == null || data.course >= 360 || data.speed <= 0) return data
  const elapsedHours = Math.max(0, now - data.timestamp) / 3600000
  const distanceNm = data.speed * elapsedHours
  const bearing = data.course * Math.PI / 180
  const latitude = data.lat * Math.PI / 180
  const longitude = data.lon * Math.PI / 180
  const angularDistance = distanceNm / 3440.065
  const estimatedLatitude = Math.asin(Math.sin(latitude) * Math.cos(angularDistance) + Math.cos(latitude) * Math.sin(angularDistance) * Math.cos(bearing))
  const estimatedLongitude = longitude + Math.atan2(Math.sin(bearing) * Math.sin(angularDistance) * Math.cos(latitude), Math.cos(angularDistance) - Math.sin(latitude) * Math.sin(estimatedLatitude))
  return { ...data, lat: estimatedLatitude * 180 / Math.PI, lon: estimatedLongitude * 180 / Math.PI, estimated: elapsedHours > 0 }
}
function selectVessel(mmsi: string) { selectedMmsi = mmsi; tracks.forEach((track, id) => { if (id !== mmsi) map.removeLayer(track) }); const vessel = vessels.get(mmsi)?.data; if (vessel) { const display = positionAt(vessel); const track = trackFor(mmsi); track.setLatLngs((trackPoints.get(mmsi) || []).map((point) => [point.lat, point.lon])).setStyle({ weight: 2.5, opacity: 1 }).addTo(map).bringToFront(); map.flyTo([display.lat, display.lon], Math.max(map.getZoom(), 7)); renderDetails(display); L.popup({ maxWidth: 300, closeButton: true }).setLatLng([display.lat, display.lon]).setContent(vesselInfo(display)).openOn(map) } }
function renderDetails(data: DisplayVessel) {
  const age = Math.max(0, Math.floor((Date.now() - data.timestamp) / 1000))
  details.innerHTML = `<div class="details-head"><span>SELECTED VESSEL</span><span class="selected-dot"></span></div><h2>${data.name || 'UNKNOWN VESSEL'}</h2><span class="mmsi">MMSI ${data.mmsi}</span><div class="metrics"><div><span>SPEED</span><strong>${data.speed?.toFixed(1) ?? '--'} <small>kn</small></strong></div><div><span>COURSE</span><strong>${formatDegrees(data.course)}</strong></div><div><span>HEADING</span><strong>${formatDegrees(data.heading)}</strong></div><div><span>${data.estimated ? 'EST. POSITION' : 'POSITION'}</span><strong>${data.lat.toFixed(5)} / ${data.lon.toFixed(5)}</strong></div><div><span>NAV STATUS</span><strong>${data.navigationStatus ?? '--'}</strong></div><div><span>REPORT AGE</span><strong class="${age > 30 ? 'stale' : ''}">${age}s</strong></div></div><div class="detail-time ${data.estimated ? 'estimated' : ''}">${data.estimated ? 'ESTIMATED FROM LAST AIS · ' : 'LAST AIS '}${formatIstTime(data.timestamp)} IST</div>`
}
const maximumZoom = 12
const nativeZoom = 8
  const map = L.map('map', { zoomControl: false, worldCopyJump: false, minZoom: 1, maxZoom: maximumZoom, maxBounds: [[-85, -180], [85, 180]], maxBoundsViscosity: 1 }).setView([-5, 70], 5)
L.control.zoom({ position: 'bottomright' }).addTo(map)
const nasaLayer = L.tileLayer('https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/BlueMarble_ShadedRelief/default/2020-01-01/GoogleMapsCompatible_Level8/{z}/{y}/{x}.jpg', { attribution: '&copy; NASA GIBS', maxZoom: nativeZoom, maxNativeZoom: nativeZoom, noWrap: true }).addTo(map)
const highResolutionLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', { attribution: '&copy; Esri World Imagery', maxZoom: maximumZoom, maxNativeZoom: 19, noWrap: true })
function updateImagery() { if (map.getZoom() > nativeZoom) { if (map.hasLayer(nasaLayer)) map.removeLayer(nasaLayer); if (!map.hasLayer(highResolutionLayer)) highResolutionLayer.addTo(map) } else { if (map.hasLayer(highResolutionLayer)) map.removeLayer(highResolutionLayer); if (!map.hasLayer(nasaLayer)) nasaLayer.addTo(map) } }
function updateResolution() { const zoom = map.getZoom(); const metersPerPixel = 156543.03392 * Math.cos(map.getCenter().lat * Math.PI / 180) / 2 ** zoom; const source = zoom > nativeZoom ? 'ESRI HD' : 'NASA'; resolution.textContent = `ZOOM ${zoom}/${maximumZoom} · RES ${metersPerPixel >= 1000 ? `${(metersPerPixel / 1000).toFixed(1)} km` : `${metersPerPixel.toFixed(0)} m`} / px · ${source}` }
map.on('zoomend moveend', updateResolution)
map.on('zoomend', updateImagery)
updateResolution()
updateImagery()
document.querySelector('#map-status')?.remove()
const markerIcon = L.divIcon({ className: 'ship-marker', html: '<span></span>', iconSize: [8, 8], iconAnchor: [4, 4] })
const crowdIcon = (size: number) => L.divIcon({ className: 'crowd-marker', html: `<span>${size}</span>`, iconSize: [30, 30], iconAnchor: [15, 15] })

function refreshCrowding() {
  crowdMarkers.forEach((marker) => map.removeLayer(marker))
  crowdMarkers.clear()
  const cells = new Map<string, Array<[string, { marker: any; data: Vessel }]>>()
  vessels.forEach((entry, mmsi) => {
    const point = map.latLngToLayerPoint(entry.marker.getLatLng())
    const key = `${Math.floor(point.x / 18)}:${Math.floor(point.y / 18)}`
    const cell = cells.get(key) || []
    cell.push([mmsi, entry])
    cells.set(key, cell)
  })
  cells.forEach((members, key) => {
    if (members.length < 2) { members.forEach(([, entry]) => { if (!map.hasLayer(entry.marker)) entry.marker.addTo(map) }); return }
    members.forEach(([, entry]) => { if (map.hasLayer(entry.marker)) map.removeLayer(entry.marker) })
    const center = members.reduce((sum, [, entry]) => { const position = entry.marker.getLatLng(); return [sum[0] + position.lat, sum[1] + position.lng] }, [0, 0]).map((value) => value / members.length) as [number, number]
    const cluster = L.marker(center, { icon: crowdIcon(members.length), zIndexOffset: 1000 }).addTo(map)
    const content = `<div class="crowd-popup"><strong>${members.length} vessels in this area</strong><small>Click a vessel to show all available data</small>${members.map(([mmsi, entry]) => `<button class="crowd-vessel" data-mmsi="${mmsi}"><span>${entry.data.name || 'UNKNOWN VESSEL'}</span><em>${mmsi}</em><small>${entry.data.speed?.toFixed(1) ?? '--'} kn · ${reportAge(entry.data.timestamp)}</small></button>`).join('')}</div>`
    cluster.bindPopup(content, { maxWidth: 300 })
    cluster.on('popupopen', (event: any) => {
      const popupElement = event.popup.getElement() as HTMLElement | undefined
      popupElement?.querySelectorAll('.crowd-vessel').forEach((element: Element) => {
        const button = element as HTMLButtonElement
        button.onclick = (clickEvent: MouseEvent) => {
          clickEvent.stopPropagation()
          const mmsi = button.dataset.mmsi
          if (mmsi) { map.closePopup(); selectVessel(mmsi) }
        }
      })
    })
    crowdMarkers.set(key, cluster)
  })
}

map.on('zoomend moveend', refreshCrowding)
map.getContainer().addEventListener('click', (event: MouseEvent) => {
  const target = (event.target as HTMLElement).closest<HTMLButtonElement>('.crowd-vessel')
  if (!target) return
  const mmsi = target.dataset.mmsi
  if (mmsi) { selectVessel(mmsi); map.closePopup() }
})

function trackFor(mmsi: string) {
  let track = tracks.get(mmsi)
  if (!track) {
    track = L.polyline([], { color: '#ffcf8a', weight: 2.5, opacity: 1, interactive: false, lineCap: 'round', lineJoin: 'round' })
    tracks.set(mmsi, track)
  }
  return track
}

function addTrackPoint(mmsi: string, lat: number, lon: number, timestamp: number) {
  const cutoff = Date.now() - historyWindow
  const points = trackPoints.get(mmsi) || []
  points.push({ lat, lon, timestamp })
  while (points[0]?.timestamp < cutoff) points.shift()
  trackPoints.set(mmsi, points)
  if (selectedMmsi === mmsi) trackFor(mmsi).setLatLngs(points.map((point) => [point.lat, point.lon])).bringToFront()
}

function addHistoryPoint(point: { mmsi: string; lat: number; lon: number; timestamp: number }) {
  if (Number.isFinite(point.lat) && Number.isFinite(point.lon)) addTrackPoint(point.mmsi, point.lat, point.lon, point.timestamp)
}

function rotateMarker(marker: any, heading?: number, course?: number) {
  const element = marker.getElement()?.querySelector('span') as HTMLElement | null
  if (element) element.style.transform = `rotate(${heading != null && heading < 511 ? heading : course ?? 0}deg)`
}

function renderList() {
  const latest = [...vessels.values()].sort((a, b) => b.data.timestamp - a.data.timestamp).slice(0, 8)
  count.textContent = String(vessels.size)
  list.innerHTML = latest.length ? latest.map(({ data }) => `<button class="vessel-row" data-mmsi="${data.mmsi}"><span class="row-dot"></span><span class="vessel-name">${data.name || `VESSEL ${data.mmsi}`}</span><span class="vessel-meta">${data.speed?.toFixed(1) ?? '--'} kn</span></button>`).join('') : '<div class="empty">Waiting for AIS positions<span>Ships will appear as the live stream connects.</span></div>'
  list.querySelectorAll<HTMLButtonElement>('.vessel-row').forEach((row) => row.onclick = () => selectVessel(row.dataset.mmsi!))
  list.querySelectorAll<HTMLButtonElement>('.vessel-row').forEach((row) => row.classList.toggle('selected', row.dataset.mmsi === selectedMmsi))
}

searchInput.addEventListener('input', () => renderSearch(searchInput.value))
searchInput.addEventListener('focus', () => { if (searchInput.value) renderSearch(searchInput.value) })

function applyVessel(data: Vessel) {
  if (!Number.isFinite(data.lat) || !Number.isFinite(data.lon)) return
  const existing = vessels.get(data.mmsi)
  addTrackPoint(data.mmsi, data.lat, data.lon, data.timestamp)
  if (existing) { existing.marker.setLatLng([data.lat, data.lon]); existing.data = data; existing.marker.setPopupContent(vesselInfo(data)); existing.marker.setTooltipContent(`<b>${data.name || data.mmsi}</b><br>MMSI ${data.mmsi}<br>${data.speed?.toFixed(1) ?? '--'} knots`); rotateMarker(existing.marker, data.heading, data.course) }
  else {
    const marker = L.marker([data.lat, data.lon], { icon: markerIcon }).addTo(map).bindTooltip(`<b>${data.name || data.mmsi}</b><br>MMSI ${data.mmsi}<br>${data.speed?.toFixed(1) ?? '--'} knots`).bindPopup(vesselInfo(data))
    marker.on('click', () => { marker.openPopup(); selectVessel(data.mmsi) })
    rotateMarker(marker, data.heading, data.course)
    vessels.set(data.mmsi, { data, marker })
  }
  if (selectedMmsi === data.mmsi) renderDetails(data)
  updated.textContent = `UPDATED ${formatIstTime(Date.now())} IST`
}

function queueVessel(data: Vessel) {
  pendingVessels.set(data.mmsi, data)
  if (updateFrame) return
  updateFrame = requestAnimationFrame(() => {
    const batch = [...pendingVessels.values()]
    pendingVessels.clear()
    updateFrame = 0
    batch.forEach(applyVessel)
    renderList()
  })
}

const socket = new WebSocket(`ws://${location.hostname}:8787`)
socket.onopen = () => { connection.innerHTML = '<span class="pulse"></span>LIVE FEED'; connection.classList.add('online') }
socket.onmessage = (event) => {
  const message = JSON.parse(event.data) as Vessel & { type?: string; status?: string; message?: string; points?: Array<{ mmsi: string; lat: number; lon: number; timestamp: number }>; events?: SilenceEvent[]; event?: SilenceEvent }
  if (message.type === 'history') { message.points?.forEach(addHistoryPoint); return }
  if (message.type === 'silence-history') { message.events?.forEach(showSilenceEvent); return }
  if (message.type === 'silence-event') { showSilenceEvent(message.event!); return }
  if (message.type === 'status') {
    if (message.status === 'connected') { connection.innerHTML = '<span class="pulse"></span>AIS LIVE'; connection.classList.add('online'); connection.classList.remove('offline') }
    else if (message.status === 'error') { connection.innerHTML = '<span class="pulse"></span>AIS ERROR'; connection.classList.add('offline'); console.error('AIS error:', message.message) }
    else { connection.innerHTML = '<span class="pulse"></span>CONNECTING AIS'; connection.classList.remove('online') }
    return
  }
  queueVessel(message)
}
socket.onerror = () => { connection.innerHTML = '<span class="pulse"></span>PROXY OFFLINE'; connection.classList.add('offline') }
socket.onclose = () => { if (!connection.classList.contains('offline')) connection.innerHTML = '<span class="pulse"></span>FEED CLOSED' }
setInterval(() => {
  vessels.forEach(({ marker, data }) => {
    const display = positionAt(data)
    marker.setLatLng([display.lat, display.lon])
  })
  if (selectedMmsi) {
    const selected = vessels.get(selectedMmsi)?.data
    if (selected) renderDetails(positionAt(selected))
  }
  if (searchInput.value) renderSearch(searchInput.value)
}, 1000)
