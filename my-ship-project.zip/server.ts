import 'dotenv/config'
import { WebSocketServer, WebSocket } from 'ws'

const port = 8787
const wss = new WebSocketServer({ port })
const upstream = new WebSocket('wss://stream.aisstream.io/v0/stream')

upstream.on('open', () => upstream.send(JSON.stringify({ APIKey: process.env.AISSTREAM_API_KEY, BoundingBoxes: [[[-60, -180], [75, 180]]] })))
upstream.on('message', (raw) => {
  const message = JSON.parse(raw.toString())
  const report = message.Message?.PositionReport
  if (!report || report.Latitude == null || report.Longitude == null) return
  const payload = JSON.stringify({ mmsi: String(message.MetaData?.MMSI ?? report.UserID ?? ''), name: message.MetaData?.ShipName?.trim() || 'UNKNOWN VESSEL', lat: report.Latitude, lon: report.Longitude, speed: report.Sog, course: report.Cog, timestamp: Date.now() })
  wss.clients.forEach((client) => { if (client.readyState === WebSocket.OPEN) client.send(payload) })
})
upstream.on('error', (error) => console.error('AIS upstream error:', error.message))
console.log(`AIS proxy listening on ws://localhost:${port}`)
